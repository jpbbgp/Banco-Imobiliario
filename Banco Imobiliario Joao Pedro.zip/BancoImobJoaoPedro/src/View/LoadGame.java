package View;

public class LoadGame {
	public LoadGame(PainelInicial f) {
		
	}
}
