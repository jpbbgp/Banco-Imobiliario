package Inicio;

import View.*;

public class IniciarJogo{
	
	public static void main(String[] args) {
		PainelInicial f=new PainelInicial();
		f.setVisible(true);	 
	}

}
